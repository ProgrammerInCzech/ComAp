Shrnutí:

Použité znalosti:
--------------------- 
OOP (uvědomuji si, že byla ukázána pouze malá část, ale mohu dodat později)
Try&Catch
Array (ať už jednoduché string tak i s obrázky)
Práce se soubory (Zápis a výpis)
Cykly, switch, podmínky
Práce se samotným oknem a nástroji
Využití knihoven a následnými funkcemi

Osobní vyjádření k chybám
-------------------------
V tomto projektu se náchází pár chyb nebo míst, kde bych věděl, jak to udělat lépe, ale znalostně
chybí metoda na lepší postup

Nápady
------------------------
Projekt nebyl 100% dokončen, díky časové tísni.
Chybí třeba radio buttony, které by se střídali současně s obrázky


Zdroje
-------------------------
Použité zdroje v projektu:
Vaše obrázky z www stránky
Ikonky: freeicons.io - user, facebook, linked in, youtube, wifi
