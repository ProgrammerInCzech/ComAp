﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Net.NetworkInformation;

namespace UkázkaPráce
{
    public partial class Main : Form
    {
        int cycle;
        public Main()
        {
            InitializeComponent();
            // Prohledává zda není přítommý soubor Dats.dll
            if (File.Exists("Dats.dll"))
            {
                PnlRegistration.Visible = false;
                StreamReader sr = new StreamReader("Dats.dll");
                LblName.Text = sr.ReadToEnd();
            }
            else
            {
                PnlRegistration.BringToFront();
                PnlOffer.Visible = false;
            }

        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            // Zavře aplikaci
            Application.Exit();
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            //shodí aplikaci na lištu
            this.WindowState = FormWindowState.Minimized;
        }

        private void BtnFB_Click(object sender, EventArgs e)
        {
            // Spustí vaš facebook profil
            Process.Start("https://www.facebook.com/ComApGlobal/");
        }

        private void BtnIN_Click(object sender, EventArgs e)
        {
            // Spustí váš LinkedIN profil
            Process.Start("https://www.linkedin.com/company/comap-group/?originalSubdomain=cz");
        }

        private void BtnYT_Click(object sender, EventArgs e)
        {
            // Spustí váš youtube kanál
            Process.Start("https://www.youtube.com/user/ComApControlSystem");
        }

        private void BtnName_Click(object sender, EventArgs e)
        {
            // V případě, že nebyla provedena registrace dříve, tak pomocí třídy zapíše jméno z text boxu & a vypíše do labelu
            User u = new User()
            {
                name = TxtName.Text
            };

            StreamWriter sw = new StreamWriter("Dats.dll");
            sw.Write(u.name);
            sw.Flush();
            sw.Close();

            LblName.Text = u.name;
            PnlOffer.Visible = true;
            PnlRegistration.Visible = false;
        }


        private void BtnBuy_MouseHover(object sender, EventArgs e)
        {
            // Změna barvy při přetážení myši přes tlačítko
            BtnBuy.BackColor = Color.Yellow;
        }

        private void BtnBuy_MouseLeave(object sender, EventArgs e)
        {
            // Navrací původní zpětnou barvu pokud kurzor myši je mimo tlačítko
            BtnBuy.BackColor = Color.YellowGreen;
        }

        private void TmrProducts_Tick(object sender, EventArgs e)
        {
            // Nabídka - chybí radio buttons na vlastní překlikávání
            Image i1 = Image.FromFile("IMG/Controler.jpg");
            Image i2 = Image.FromFile("IMG/RemoteDisplays.jpg");
            Image i3 = Image.FromFile("IMG/SwitchGear&Protections.jpg");
            Image i4 = Image.FromFile("IMG/Communication.jpg");

            string[] Product = { "Controllers", "Remote displays", "Switchgear control and Protections", "Communications" };
            string[] Description = { "The best controllers \n in Czech Republic!", "Remote displays in high quality", "The best performance \n on the current market", "Leader in communication" };
            Image[] Img = { i1, i2, i3, i4 };


            cycle += 1;

            for (int i = 0; i < cycle; i++)
            {
                LblProduct.Text = Product[i];
                LblDescription.Text = Description[i];
                PnlPicture.BackgroundImage = Img[i];

            }
            if (cycle > 3)
            {
                cycle = 0;
            }
            // Kontroluje připojení k wifi
            try
            {

                bool connect = NetworkInterface.GetIsNetworkAvailable();
                if (connect == true)
                {
                    PnlWifi.BackgroundImage = Image.FromFile("IMG/WifiEnabled.png");
                }
                else
                {
                    PnlWifi.BackgroundImage = Image.FromFile("IMG/WifiDisabled.png");
                }

            }
            catch
            {
                MessageBox.Show("error");
            }
        
    
           
        }


    }
}
