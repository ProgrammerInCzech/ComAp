﻿
namespace UkázkaPráce
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.panel1 = new System.Windows.Forms.Panel();
            this.BtnClose = new System.Windows.Forms.Button();
            this.PnlWifi = new System.Windows.Forms.Panel();
            this.BtnExit = new System.Windows.Forms.Button();
            this.LblName = new System.Windows.Forms.Label();
            this.BtnIN = new System.Windows.Forms.Button();
            this.BtnFB = new System.Windows.Forms.Button();
            this.PnlRegistration = new System.Windows.Forms.Panel();
            this.BtnName = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.BtnYT = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PnlOffer = new System.Windows.Forms.Panel();
            this.BtnBuy = new System.Windows.Forms.Button();
            this.LblDescription = new System.Windows.Forms.Label();
            this.LblProduct = new System.Windows.Forms.Label();
            this.PnlPicture = new System.Windows.Forms.Panel();
            this.TmrProducts = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.PnlRegistration.SuspendLayout();
            this.PnlOffer.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.BtnClose);
            this.panel1.Controls.Add(this.PnlWifi);
            this.panel1.Controls.Add(this.BtnExit);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(940, 41);
            this.panel1.TabIndex = 0;
            // 
            // BtnClose
            // 
            this.BtnClose.FlatAppearance.BorderSize = 0;
            this.BtnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BtnClose.Location = new System.Drawing.Point(863, -1);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(36, 34);
            this.BtnClose.TabIndex = 1;
            this.BtnClose.Text = "━";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // PnlWifi
            // 
            this.PnlWifi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PnlWifi.Location = new System.Drawing.Point(18, 5);
            this.PnlWifi.Name = "PnlWifi";
            this.PnlWifi.Size = new System.Drawing.Size(28, 30);
            this.PnlWifi.TabIndex = 9;
            // 
            // BtnExit
            // 
            this.BtnExit.FlatAppearance.BorderSize = 0;
            this.BtnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BtnExit.Location = new System.Drawing.Point(905, -1);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(36, 34);
            this.BtnExit.TabIndex = 0;
            this.BtnExit.Text = "✕";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // LblName
            // 
            this.LblName.AutoSize = true;
            this.LblName.Font = new System.Drawing.Font("Rondalo", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblName.Location = new System.Drawing.Point(78, 518);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(18, 25);
            this.LblName.TabIndex = 5;
            this.LblName.Text = "-";
            // 
            // BtnIN
            // 
            this.BtnIN.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnIN.BackgroundImage")));
            this.BtnIN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnIN.FlatAppearance.BorderSize = 0;
            this.BtnIN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnIN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnIN.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BtnIN.Location = new System.Drawing.Point(843, 513);
            this.BtnIN.Name = "BtnIN";
            this.BtnIN.Size = new System.Drawing.Size(29, 33);
            this.BtnIN.TabIndex = 3;
            this.BtnIN.UseVisualStyleBackColor = true;
            this.BtnIN.Click += new System.EventHandler(this.BtnIN_Click);
            // 
            // BtnFB
            // 
            this.BtnFB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnFB.BackgroundImage")));
            this.BtnFB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnFB.FlatAppearance.BorderSize = 0;
            this.BtnFB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnFB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BtnFB.Location = new System.Drawing.Point(797, 513);
            this.BtnFB.Name = "BtnFB";
            this.BtnFB.Size = new System.Drawing.Size(29, 33);
            this.BtnFB.TabIndex = 2;
            this.BtnFB.UseVisualStyleBackColor = true;
            this.BtnFB.Click += new System.EventHandler(this.BtnFB_Click);
            // 
            // PnlRegistration
            // 
            this.PnlRegistration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlRegistration.Controls.Add(this.BtnName);
            this.PnlRegistration.Controls.Add(this.label3);
            this.PnlRegistration.Controls.Add(this.TxtName);
            this.PnlRegistration.Controls.Add(this.label2);
            this.PnlRegistration.Location = new System.Drawing.Point(274, 179);
            this.PnlRegistration.Name = "PnlRegistration";
            this.PnlRegistration.Size = new System.Drawing.Size(419, 219);
            this.PnlRegistration.TabIndex = 6;
            // 
            // BtnName
            // 
            this.BtnName.Location = new System.Drawing.Point(227, 115);
            this.BtnName.Name = "BtnName";
            this.BtnName.Size = new System.Drawing.Size(85, 23);
            this.BtnName.TabIndex = 5;
            this.BtnName.Text = "Enter";
            this.BtnName.UseVisualStyleBackColor = true;
            this.BtnName.Click += new System.EventHandler(this.BtnName_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(100, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "NAME";
            // 
            // TxtName
            // 
            this.TxtName.Location = new System.Drawing.Point(157, 89);
            this.TxtName.Name = "TxtName";
            this.TxtName.Size = new System.Drawing.Size(155, 20);
            this.TxtName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(74, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(272, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "PLEASE ENTER YOUR NAME";
            // 
            // BtnYT
            // 
            this.BtnYT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnYT.BackgroundImage")));
            this.BtnYT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnYT.FlatAppearance.BorderSize = 0;
            this.BtnYT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnYT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnYT.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BtnYT.Location = new System.Drawing.Point(890, 513);
            this.BtnYT.Name = "BtnYT";
            this.BtnYT.Size = new System.Drawing.Size(29, 33);
            this.BtnYT.TabIndex = 7;
            this.BtnYT.UseVisualStyleBackColor = true;
            this.BtnYT.Click += new System.EventHandler(this.BtnYT_Click);
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel2.Location = new System.Drawing.Point(34, 513);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(38, 35);
            this.panel2.TabIndex = 8;
            // 
            // PnlOffer
            // 
            this.PnlOffer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlOffer.Controls.Add(this.BtnBuy);
            this.PnlOffer.Controls.Add(this.LblDescription);
            this.PnlOffer.Controls.Add(this.LblProduct);
            this.PnlOffer.Controls.Add(this.PnlPicture);
            this.PnlOffer.Location = new System.Drawing.Point(172, 142);
            this.PnlOffer.Name = "PnlOffer";
            this.PnlOffer.Size = new System.Drawing.Size(587, 278);
            this.PnlOffer.TabIndex = 6;
            // 
            // BtnBuy
            // 
            this.BtnBuy.BackColor = System.Drawing.Color.YellowGreen;
            this.BtnBuy.FlatAppearance.BorderSize = 0;
            this.BtnBuy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBuy.Font = new System.Drawing.Font("Rondalo", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBuy.Location = new System.Drawing.Point(329, 166);
            this.BtnBuy.Name = "BtnBuy";
            this.BtnBuy.Size = new System.Drawing.Size(126, 24);
            this.BtnBuy.TabIndex = 3;
            this.BtnBuy.Text = "BUY";
            this.BtnBuy.UseVisualStyleBackColor = false;
            this.BtnBuy.MouseLeave += new System.EventHandler(this.BtnBuy_MouseLeave);
            this.BtnBuy.MouseHover += new System.EventHandler(this.BtnBuy_MouseHover);
            // 
            // LblDescription
            // 
            this.LblDescription.AutoSize = true;
            this.LblDescription.Font = new System.Drawing.Font("Rondalo", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDescription.Location = new System.Drawing.Point(326, 106);
            this.LblDescription.Name = "LblDescription";
            this.LblDescription.Size = new System.Drawing.Size(12, 17);
            this.LblDescription.TabIndex = 2;
            this.LblDescription.Text = "-";
            // 
            // LblProduct
            // 
            this.LblProduct.AutoSize = true;
            this.LblProduct.Font = new System.Drawing.Font("Rondalo", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblProduct.Location = new System.Drawing.Point(34, 36);
            this.LblProduct.Name = "LblProduct";
            this.LblProduct.Size = new System.Drawing.Size(15, 22);
            this.LblProduct.TabIndex = 1;
            this.LblProduct.Text = "-";
            // 
            // PnlPicture
            // 
            this.PnlPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PnlPicture.Location = new System.Drawing.Point(18, 71);
            this.PnlPicture.Name = "PnlPicture";
            this.PnlPicture.Size = new System.Drawing.Size(199, 140);
            this.PnlPicture.TabIndex = 0;
            // 
            // TmrProducts
            // 
            this.TmrProducts.Enabled = true;
            this.TmrProducts.Interval = 3000;
            this.TmrProducts.Tick += new System.EventHandler(this.TmrProducts_Tick);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(940, 558);
            this.Controls.Add(this.PnlOffer);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.BtnYT);
            this.Controls.Add(this.PnlRegistration);
            this.Controls.Add(this.LblName);
            this.Controls.Add(this.BtnIN);
            this.Controls.Add(this.BtnFB);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.panel1.ResumeLayout(false);
            this.PnlRegistration.ResumeLayout(false);
            this.PnlRegistration.PerformLayout();
            this.PnlOffer.ResumeLayout(false);
            this.PnlOffer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Button BtnFB;
        private System.Windows.Forms.Button BtnIN;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.Panel PnlRegistration;
        private System.Windows.Forms.Button BtnName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxtName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BtnYT;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel PnlOffer;
        private System.Windows.Forms.Label LblDescription;
        private System.Windows.Forms.Label LblProduct;
        private System.Windows.Forms.Panel PnlPicture;
        private System.Windows.Forms.Button BtnBuy;
        private System.Windows.Forms.Timer TmrProducts;
        private System.Windows.Forms.Panel PnlWifi;
    }
}