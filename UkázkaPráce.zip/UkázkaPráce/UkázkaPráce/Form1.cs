﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UkázkaPráce
{
    public partial class UkázkaPráce : Form
    {
        // Počáteční barva
        int R = 255;
        int G = 255;
        int B = 255;
        /* Snaha o změnu průhlednosti pouze přes alfu, ale VS to nezobrazilo. Určitě je snažší postup než přes celé RGB
        int Alfa;*/

        // Počet cyklů u barev. Jeden cyklus zobrazuje barvu, druhý naopak ji zneviditelňuje
        int cycle;

        // pro objevení textu ve správný čas
        int text;
        public UkázkaPráce()
        {
            InitializeComponent();
          
        }

        private void TmrColor(object sender, EventArgs e)
        {
            //Neustálý přechod barev
            switch(cycle)
            {
                case 0:
                if (R >= 1 && G >= 1 && B>= 1)
                {
                    R -= 1;
                    G -= 1;
                    B -= 1;
                        LblTitle.ForeColor = Color.FromArgb(R, G, B);
                }
                    break;

                case 1:
                if(R <= 254 && G <= 254 & B <=254)
                {
                    R += 1;
                    G += 1;
                    B += 1;
                        LblTitle.ForeColor = Color.FromArgb(R, G, B);
                }

                    break;
            }
           
        }

        private void TmrText_Tick(object sender, EventArgs e)
        {
            // pole textu
            string[] TitleText = {"-present-", "project comAp" };

            // celé slouží pro cyklování barev a textu a jejich nulování, aby to nepřešlo přes hranice
            cycle += 1;
            if (text >= 2)
            {
                TmrText.Stop();
                this.Hide();
                Main m = new Main();
                m.Show();
            }

            if (cycle > 2)
            {
                cycle = 0;
                LblTitle.Text = TitleText[text];
                text += 1;

            }
            
            
           

        }
    }

}

